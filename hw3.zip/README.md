# MEME
Multiple EM for Motif Elicitation for discovering motifs in a group of related DNA or protein sequences.

Implementing as a homework for CESP527 CompBio- https://courses.cs.washington.edu/courses/csep527/20au/hw/hw3.html

Please run 

```
pip install -r requirements.txt
```

## How to Use
```
python src/meme.py -tr data/hw3-train.fasta -tt data/hw3-test.fasta
```

